from django.shortcuts import render
from django.http import HttpResponse

import pymongo
import json

def test(request):
    print("test")
    return render(request, 'index.html')

# Create your views here.
def db_up_status(request):
    try:
        client = pymongo.MongoClient('mongodb+srv://unknown_person221:DtW8P9tDnT6eE6Jt@cluster0.xxbvc.mongodb.net/myFirstDatabase?retryWrites=true&w=majority')
        
        if client:
            db = client.data
            collection = db.news

            # for i in collection:
            #     print(i)
            #     # print(collection)

            # return render(request, 'index.html')
            return HttpResponse('DB Online')

    except:
        return HttpResponse("No connection could be made")

# --------------- Get data DB --------------- #
def get_data(collection_name):
    pass

# --------------- Add to DB --------------- #

# --------------- Update DB --------------- #

# --------------- Delete DB --------------- #