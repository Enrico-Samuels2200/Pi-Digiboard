from django.urls import path
from . import views

# URL Conf
urlpatterns = [
    path('status/', views.db_up_status),
    path('test/', views.test)
]